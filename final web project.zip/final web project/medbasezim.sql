-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2016 at 12:00 AM
-- Server version: 5.5.49-log
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `medbasezim`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `name` varchar(256) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `gender` varchar(256) DEFAULT NULL,
  `medical_aid_insurer` varchar(256) DEFAULT NULL,
  `medical_aid_scheme` varchar(256) DEFAULT NULL,
  `occupation` varchar(256) DEFAULT NULL,
  `password` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`name`, `email`, `gender`, `medical_aid_insurer`, `medical_aid_scheme`, `occupation`, `password`) VALUES
('mike', 'q', '2', '4', '5', '6', '12345'),
('alex', 'w@gmail.com', 'male', 'cimas', 'gold', 'work', '12345'),
('tom', 'tom@gmail.com', 'male', 'cimas', 'silver', 'work', '123456'),
('cb', '1', '1', '1', '1', '1', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `testvar`
--

CREATE TABLE IF NOT EXISTS `testvar` (
  `name` varchar(20) DEFAULT NULL,
  `surname` varchar(20) DEFAULT NULL,
  `age` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `testvar`
--

INSERT INTO `testvar` (`name`, `surname`, `age`) VALUES
('mike', 'banga', 78);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
